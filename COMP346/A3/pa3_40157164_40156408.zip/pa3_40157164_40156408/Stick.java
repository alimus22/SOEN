public class Stick {

        boolean available;

        public Stick() {
            available = true;
        }

        public void setAvailability(boolean b) {
            available = b;
        }

        public boolean getAvailability() {
            return available;
        }

}
